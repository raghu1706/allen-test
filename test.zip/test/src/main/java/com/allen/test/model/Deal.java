package com.allen.test.model;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

public class Deal {

    private int id;
    private double price;
    private int totalUnits;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Set<Integer> claimedUsers;

    public Deal(int id, double price, int totalUnits, LocalDateTime startTime, LocalDateTime endTime) {
        this.id = id;
        this.price = price;
        this.totalUnits = totalUnits;
        this.startTime = startTime;
        this.endTime = endTime;
        this.claimedUsers = new HashSet<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getTotalUnits() {
        return totalUnits;
    }

    public void setTotalUnits(int totalUnits) {
        this.totalUnits = totalUnits;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public Set<Integer> getClaimedUsers() {
        return claimedUsers;
    }

    public void setClaimedUsers(Set<Integer> claimedUsers) {
        this.claimedUsers = claimedUsers;
    }

    public boolean canClaim(int userId) {
        return totalUnits>0 && isDealActive() && !claimedUsers.contains(userId);
    }

    public boolean isDealActive() {
        LocalDateTime now = LocalDateTime.now();
        return now.isAfter(startTime) && now.isBefore(endTime);
    }

    public boolean claim(int userId) {
        if(canClaim(userId)) {
            claimedUsers.add(userId);
            totalUnits--;
            return true;
        }
        return false;
    }
}
