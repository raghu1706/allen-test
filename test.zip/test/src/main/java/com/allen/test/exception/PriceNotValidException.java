package com.allen.test.exception;

public class PriceNotValidException extends RuntimeException{

    public PriceNotValidException(String message) {
        super(message);
    }
}
