package com.allen.test.repository;

import com.allen.test.model.Deal;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryRepositoryImpl implements IDealRepository {

    private Map<Integer,Deal> dealMap;

    public InMemoryRepositoryImpl(){
        dealMap = new ConcurrentHashMap<>();
    }


    @Override
    public void createDeal(Deal deal) {

        dealMap.put(deal.getId(), deal);
    }

    @Override
    public boolean claimDeal(int dealId, int userId) {
        Deal deal = dealMap.get(dealId);
        if(deal!=null) {
            return deal.claim(userId);
        }
        return false;
    }

    @Override
    public void endDeal(int dealId) {
        Deal deal = dealMap.get(dealId);
        if(deal!=null) {
            deal.setEndTime(LocalDateTime.now());
        }
    }

    @Override
    public void updateDeal(int dealId, int noOfItems, LocalDateTime endTime) {
        Deal deal = dealMap.get(dealId);
        if(deal!=null) {
            deal.setEndTime(endTime);
            deal.setTotalUnits(noOfItems);
        }
    }

    @Override
    public Deal viewDeal(int dealId) {
        return dealMap.get(dealId);
    }
}
