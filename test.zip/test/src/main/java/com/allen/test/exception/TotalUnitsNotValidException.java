package com.allen.test.exception;

public class TotalUnitsNotValidException extends RuntimeException{

    public TotalUnitsNotValidException(String message) {
        super(message);
    }
}
