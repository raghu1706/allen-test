package com.allen.test.controller;


import com.allen.test.exception.PriceNotValidException;
import com.allen.test.exception.TotalUnitsNotValidException;
import com.allen.test.model.Deal;
import com.allen.test.service.DealService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
public class DealController {

    @Autowired private DealService dealService;

    @PostMapping("/deals")
    public ResponseEntity<String> createDeal(@RequestBody Deal deal) {
        try {
            dealService.createDeal(deal);
            return ResponseEntity.ok("Successfully created Deal");
        } catch (PriceNotValidException e) {
            return ResponseEntity.badRequest().body("Price Not Valid");
        } catch (TotalUnitsNotValidException e) {
            return ResponseEntity.badRequest().body("TotalUnits Not Valid");
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Internal Server Error");
        }
    }

    @GetMapping("/deals")
    public Deal viewDeal(@RequestParam int dealId) {
        return dealService.viewDeal(dealId);
    }

    @PutMapping("/deals/{dealId}")
    public void updateDeal(@PathVariable int dealId, @RequestParam int noOfItems, @RequestParam String endTime) {
        dealService.updateDeal(dealId, noOfItems, endTime);
    }

    @PostMapping("/claim")
    public ResponseEntity<String> claimDeal(@RequestParam int dealId, @RequestParam int userId) {
        if(dealService.claimDeal(dealId, userId)) {
            return ResponseEntity.ok("Successfully Claimed");
        }
        return ResponseEntity.badRequest().body("Deal cannot be claimed");
    }

    @PutMapping("/deals/end/{dealId}")
    public void endDeal(@PathVariable int dealId) {
        dealService.endDeal(dealId);
    }
}
