package com.allen.test.service;

import com.allen.test.exception.PriceNotValidException;
import com.allen.test.exception.TotalUnitsNotValidException;
import com.allen.test.model.Deal;
import com.allen.test.repository.IDealRepository;
import com.allen.test.repository.InMemoryRepositoryImpl;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class DealService {

    private IDealRepository iDealRepository;
    public DealService() {
        this.iDealRepository = new InMemoryRepositoryImpl();
    }

    public void createDeal(Deal deal) {
        if(deal.getPrice()<=0) {
            throw new PriceNotValidException("Price Not Valid");
        }
        if(deal.getTotalUnits()<=0) {
            throw new TotalUnitsNotValidException("Total Units Not Valid");
        }
        iDealRepository.createDeal(deal);
    }

    public boolean claimDeal(int dealId, int userId) {
        return iDealRepository.claimDeal(dealId,userId);
    }

    public void endDeal(int dealId) {
        iDealRepository.endDeal(dealId);
    }

    public void updateDeal(int dealId, int noOfItems, String endTime) {
        iDealRepository.updateDeal(dealId, noOfItems, LocalDateTime.parse(endTime));
    }

    public Deal viewDeal(int dealId) {
        return iDealRepository.viewDeal(dealId);
    }
}
