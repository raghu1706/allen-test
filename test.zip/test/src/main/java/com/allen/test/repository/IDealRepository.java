package com.allen.test.repository;

import com.allen.test.model.Deal;

import java.time.LocalDateTime;

public interface IDealRepository {

    void createDeal(Deal deal);
    boolean claimDeal(int dealId, int userId);
    void endDeal(int dealId);
    void updateDeal(int dealId, int noOfItems, LocalDateTime endTime);
    Deal viewDeal(int dealId);
}
